<!DOCTYPE html>
<html lang="en">
@include('_partials/head')
<body>
@include('_partials/nav')

      <div class="main-card card">
        @yield('content')
      </div>

      <footer class="bg-dark text-center text-lg-start footeris">
        <div class="text-center p-3 text-light">
          © 2020 Copyright: Matas Macijauskas
        </div>
      </footer>
</body>
</html>