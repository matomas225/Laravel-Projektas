<!DOCTYPE html>
<html lang="en">
<?php echo $__env->make('_partials/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
<?php echo $__env->make('_partials/nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <div class="main-card card">
        <?php echo $__env->yieldContent('content'); ?>
      </div>

      <footer class="bg-dark text-center text-lg-start footeris">
        <div class="text-center p-3 text-light">
          © 2020 Copyright: Matas Macijauskas
        </div>
      </footer>
</body>
</html><?php /**PATH /var/www/html/resources/views/main.blade.php ENDPATH**/ ?>